--13.   Le nom et l annee de toutes les conferences organisees par un scientifique donne.

SELECT Nom_conf,EXTRACT(YEAR FROM date_debut) as annee FROM Conference WHERE idPresident=7
