--14.   Le nom et le prenom du scientifique qui n a jamais encadre

SELECT s.Nom,s.Prenom
FROM(SELECT idPersonnel,Nom,Prenom from Personnel) as s
JOIN ((SELECT idScientifique from Scientifique)
EXCEPT
(SELECT idScientifique from ScientifiqueEncadreDoctorant))as e
ON e.idScientifique=s.idPersonnel
