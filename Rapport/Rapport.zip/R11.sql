--11.   Les personnes ayant participe a toutes les journees portes ouvertes

SELECT DISTINCT idPersonnel FROM PersonnelParticipeJPO j1
WHERE NOT EXISTS(SELECT * FROM JPO j2
WHERE NOT EXISTS(SELECT * FROM PersonnelParticipeJPO j3
WHERE (j1.idPersonnel=j3.idPersonnel AND j2.idJPO=j3.idJPO)))