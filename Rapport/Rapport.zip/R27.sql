--27.   Les pays qui sont pr�sents � tous les projets

SELECT pc.Pays
FROM (SELECT DISTINCT COUNT(ppp.TitreProjet) as nbProj, pa.Pays 
FROM
(SELECT DISTINCT Pays, idPartenaire FROM Partenaire)as pa
JOIN 
(SELECT * FROM PartenaireParticipeProjet)as ppp
ON ppp.idPartenaire=pa.idPartenaire
GROUP BY pa.Pays) as pc
WHERE pc.nbProj=(SELECT COUNT(*) FROM Projet_recherche)
