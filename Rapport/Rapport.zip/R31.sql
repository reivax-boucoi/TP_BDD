--31. L��tablissement d�enseignement ayant le plus grand nombre d�enseignant chercheur

SELECT idcnt.idEtablissement FROM 
(SELECT idEtablissement,COUNT(*) as cntEnseignants
	FROM Enseignant_chercheur 
	GROUP BY idEtablissement) as idcnt
	
WHERE idcnt.cntEnseignants=(SELECT max(nc.cntEnseignants)
FROM (
	SELECT idEtablissement,COUNT(*) as cntEnseignants
	FROM Enseignant_chercheur 
	GROUP BY idEtablissement) as nc)