--21.   Le nombre de collaborateurs par pays

SELECT pn.Pays, COUNT(idAuteur)
FROM(SELECT Pays,Nom  FROM Labo_externe) as pn
LEFT JOIN(SELECT idAuteur, NomLabo FROM Auteur) as a
ON pn.Nom=a.NomLabo
GROUP BY pn.Pays