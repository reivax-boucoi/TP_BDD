--5.     Pour chaque doctorant, on souhaiterait recuperer le nombre de ses publications

SELECT d.idDoctorant,p.cntPubli
FROM (SELECT idPersonnel,COUNT(idPublication) as cntPubli FROM PersonnelPublie GROUP BY idPersonnel)as p
RIGHT JOIN (SELECT idDoctorant FROM Doctorant) as d
ON d.idDoctorant=p.idPersonnel