--12.   Les personnes qui n ont jamais participe aux journees portes ouvertes

(SELECT idPersonnel from Personnel)
EXCEPT
(SELECT idPersonnel from PersonnelParticipeJPO)
