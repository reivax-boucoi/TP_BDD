--24.   Les scientifiques qui ont plus de 3 doctorants qui ont d�but� leur th�se il y a moins de 2 ans.

-- NON TESTABLE ACTUELLEMENT !!!!!!!!

SELECT s.idScientifique FROM (
SELECT idScientifique, COUNT(idDoctorant) as NbDocts FROM ScientifiqueEncadreDoctorant
WHERE idDoctorant IN (
SELECT idDoctorant FROM Doctorant
WHERE idDoctorant IN (
SELECT idPersonnel FROM Personnel
WHERE EXTRACT(YEAR FROM Date_recrutement)>=(EXTRACT(YEAR FROM CURRENT_DATE)-2)))
GROUP BY idScientifique) as s
WHERE s.NbDocts>3