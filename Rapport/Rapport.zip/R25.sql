--25.   Les doctorants qui ont au moins une publication chaque ann�e depuis leur recrutement

SELECT np.idPersonnel
FROM 
(SELECT DISTINCT dp.idPersonnel, COUNT(pa.annee_publication) as ap
FROM(SELECT idPersonnel, idPublication FROM PersonnelPublie
WHERE idPersonnel IN (SELECT idDoctorant FROM Doctorant))as dp
JOIN
(SELECT idPublication, annee_publication FROM Publication) as pa
ON dp.idPublication=pa.idPublication
GROUP BY dp.idPersonnel)as np
JOIN
(SELECT idPersonnel, EXTRACT(YEAR FROM CURRENT_DATE)-EXTRACT(YEAR FROM Date_recrutement) as Nbannees FROM Personnel) as tp
ON tp.idPersonnel=np.idPersonnel
WHERE np.ap = tp.Nbannees
