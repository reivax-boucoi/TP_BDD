--18.   Les scientifiques qui ont que des doctorants ayant soutenus et pas de doctorant en cours


SELECT idScientifique FROM ScientifiqueEncadreDoctorant 
EXCEPT
SELECT idScientifique FROM ScientifiqueEncadreDoctorant 
WHERE (idDoctorant IN (SELECT idDoctorant FROM Doctorant WHERE (date_soutenance >= CURRENT_DATE)))
