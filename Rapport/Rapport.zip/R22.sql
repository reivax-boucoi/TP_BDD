--22.   Les doctorants qui ont un seul encadrant et qui ont toujours des publications qu avec leur encadrant

SELECT idDoctorant FROM Doctorant 
WHERE idDoctorant IN (
SELECT idPersonnel FROM PersonnelPublie
WHERE idPublication IN (

(SELECT idPublication FROM PersonnelPublie 
WHERE idPersonnel in
(SELECT idScientifique FROM ScientifiqueEncadreDoctorant
GROUP BY idScientifique)

INTERSECT

SELECT idPublication FROM PersonnelPublie 
WHERE idPersonnel in
(SELECT idDoctorant FROM ScientifiqueEncadreDoctorant
GROUP BY idDoctorant
HAVING COUNT(*)=1 ))))