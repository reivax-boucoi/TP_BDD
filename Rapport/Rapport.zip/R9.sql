--9.     Le nombre d enseignants chercheurs par etablissement d enseignement

(SELECT idEtablissement,COUNT(*) as cntEnseignants FROM Enseignant_chercheur GROUP BY idEtablissement)
