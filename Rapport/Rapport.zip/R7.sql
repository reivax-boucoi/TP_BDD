--7.     Le nombre de doctorants du laboratoire

SELECT COUNT(*) as nbDoctorants FROM Doctorant;