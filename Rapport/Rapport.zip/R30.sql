--30.   Le nombre de conferences de classe A organisees par le laboratoire par annee

SELECT cd.annee, COUNT(cd.Nom_conf) as NbConf FROM
(SELECT Nom_conf,EXTRACT(YEAR FROM date_debut) as annee FROM Conference) as cd
LEFT JOIN
(SELECT nom_conference_journal FROM TypeConf WHERE classe_conference='A') as na
ON na.nom_conference_journal=cd.Nom_conf
GROUP BY cd.anne